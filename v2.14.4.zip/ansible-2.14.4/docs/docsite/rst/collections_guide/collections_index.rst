.. _index_collections:

Collections index
=================

You can find an index of collections at :ref:`list_of_collections`.