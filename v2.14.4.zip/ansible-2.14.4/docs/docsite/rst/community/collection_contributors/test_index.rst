.. _testing_collections_guide:

**********************************************
Testing Collection Contributions
**********************************************

This section focuses on the different tests a contributor should run on their collection PR.

.. toctree::
   :maxdepth: 1

   collection_test_pr_locally
   collection_unit_tests
   collection_integration_tests
