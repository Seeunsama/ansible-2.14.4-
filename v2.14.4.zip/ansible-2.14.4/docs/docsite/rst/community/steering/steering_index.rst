.. _community_steering_committee:

************************************
Ansible Community Steering Committee
************************************

This section focuses on the guidelines and membership of the Ansible Community Steering Committee.

.. toctree::
   :maxdepth: 1

   community_steering_committee
   steering_committee_membership
   steering_committee_past_members
