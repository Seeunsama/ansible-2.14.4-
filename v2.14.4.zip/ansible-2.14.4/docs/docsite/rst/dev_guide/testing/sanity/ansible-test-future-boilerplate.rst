ansible-test-future-boilerplate
===============================

The ``_internal`` code for ``ansible-test`` requires the following ``__future__`` import:

.. code-block:: python

    from __future__ import annotations
